from django.apps import AppConfig


class TapasappConfig(AppConfig):
    name = 'tapasapp'
