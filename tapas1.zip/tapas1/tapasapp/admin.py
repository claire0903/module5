from django.contrib import admin
from .models import Dish

# Register your models here.
admin.site.register(Dish)